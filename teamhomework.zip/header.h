#pragma once
void  Selection_sort(int* arr, int  Amount_of_elements);
void  Merger_sort(int* arr, int* tmp, int left_index, int right_index);